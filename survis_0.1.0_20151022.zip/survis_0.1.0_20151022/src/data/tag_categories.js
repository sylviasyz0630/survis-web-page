define({
	tagCategories: {
		"type": {
			"description": "type of the paper"
		}
	}
});